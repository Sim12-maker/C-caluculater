
========== C++ Calculator =======   
A straightforward C++ calculator that performs

1.Arithmetic Unit{"+","-","*","/"}  

2.Shapes areas{Square,Triangle,Rectangle,Circle-radius}

=======⚙️ FEATURES =========

1.Simple menu for choosing operations.

2.Supports repeated calculations in a loop.

3.Colored output

4.Validates user input and displays error messages.


======== How to Use ===========
1. Paste your calculator code into the editor
2. Tap Run ▶️ to compile and execute.
3. Follow on-screen instruction to perform calculations.

This created by sim12-maker
>>> https://github.com/Sim12-maker

